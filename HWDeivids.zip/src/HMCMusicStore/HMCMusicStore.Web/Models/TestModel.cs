﻿namespace HMCMusicStore.Web.Models
{
    public class TestModel
    {
        public string ItemId { get; set; }
    }
}
